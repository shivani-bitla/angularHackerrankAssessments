import React, { useState } from 'react';
import { idText } from 'typescript';
import { flashCardsData } from '../../data/cards-data';
import { FlashCardProps } from '../../types/FlashCard';
import "./index.css"

const FlashCard: React.FC<FlashCardProps> = (idtext) => {
  let [isFlipped,setIsFlipped] = useState(false);

  return (
    <div
      className="flashcard"
      onClick={() => { 
        setIsFlipped(a=>!a)
      }}
      data-testid={`flashcard-container-1`}
    >
      <div className={`flashcard-content ${isFlipped ? '.flipped' : ''}`}>
        <div className="front" data-testid={id}>{question}</div>
        <div className="back" data-testid={id}>{answer}</div>
      </div>
    </div>
  );
};

export default FlashCard;
